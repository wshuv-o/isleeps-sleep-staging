# Writing DNA — research operating kit

A portable, field-independent kit for running a rigorous research project with an AI
collaborator (Claude Code or similar). Drop it into any new project root and adapt.

## Contents

| File | What it is | How to use |
|---|---|---|
| `RESEARCH_OPERATING_MANUAL.md` | The **"geist"** of a project operating manual — domain-agnostic principles, phased workflow, when-in-doubt defaults, quality gates. Distilled from a project-specific `CLAUDE.md`. | Rename to `CLAUDE.md` in your project root, fill in the **PROJECT BRIEF** placeholders (§0), prune what doesn't apply. |
| `JAHIN_WRITING_BIBLE.md` | Abrar Jahin's publication system, distilled and generalized — sentence rules, paragraph moves, structural defaults, phrases-to-avoid, and the "know when to stop" meta-skill. | Read before drafting. Apply at **80–85%**, not 100% (see the calibration note at the top). |
| `jahins_work/` | Four papers written under this system. The rules above are abstractions; these are what they look like executed. | Read one alongside the bible — the structural moves are easier to see in a finished paper than in a rule list. |

## Suggested workflow for a new project

1. Copy `RESEARCH_OPERATING_MANUAL.md` → `CLAUDE.md`, fill in §0.
2. Point your AI collaborator at it: *"Read CLAUDE.md in full, inspect the directory,
   tell me which phase we're in and the next action, then wait."*
3. Keep `JAHIN_WRITING_BIBLE.md` open during Phase 4 (drafting).
4. When a structural question comes up that the bible does not settle, look at how one
   of the papers in `jahins_work/` handled it.

## The worked examples, and their licences

All four are redistributable; three are formally open access under CC BY 4.0, which
requires attribution. Cite the originals, not this archive.

**KACQ-DCNN: Uncertainty-Aware Interpretable Kolmogorov–Arnold Classical–Quantum
Dual-Channel Neural Network**
*Computers in Biology and Medicine* — `1-s2.0-S0010482525013289-main.pdf`
Open access under **CC BY 4.0** (http://creativecommons.org/licenses/by/4.0/).

**QAmplifyNet: Pushing the Boundaries of Supply Chain Backorder Prediction Using
Interpretable Hybrid Quantum-Classical Neural Network**
Md Abrar Jahin, Md Sakib Hossain Shovon, Md. Saiful Islam, Jungpil Shin
*Scientific Reports* — `s41598-023-45406-7 (2).pdf`
Open access under **Creative Commons Attribution 4.0**.

**TriQXNet: Forecasting Dst Index from Solar Wind Data Using an Interpretable Parallel
Classical–Quantum Framework with Uncertainty Quantification**
arXiv:2407.06658v3 — `2407.06658v3.pdf`

**Lorentz-Equivariant Quantum Graph Neural Network for High-Energy Physics**
Md Abrar Jahin, Md. Akmol Masud, Md Wahiduzzaman Suva, M. F. Mridha, Nilanjan Dey
arXiv:2411.01641v3 — `2411.01641v3.pdf`

## Provenance

Generalized from the `bci-review` project operating manual (`CLAUDE.md`) and the
`CLAUDE_NOTES.md` "Jahin publication system" notes. Both markdown documents here are
field-independent distillations; the papers are the concrete instances they came from.

The raw source artifact the writing bible was distilled from — Abrar Jahin's
paper-structuring notes for a specific in-progress paper — is deliberately not
included. It is project-specific rather than general, and it describes work in
progress rather than published results.
