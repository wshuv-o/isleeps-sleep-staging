# Research Operating Kit

A portable, field-independent kit for running a rigorous research project with an AI
collaborator (Claude Code or similar). Drop it into any new project root and adapt.

## Contents

| File | What it is | How to use |
|---|---|---|
| `RESEARCH_OPERATING_MANUAL.md` | The **"geist"** of a project operating manual — domain-agnostic principles, phased workflow, when-in-doubt defaults, quality gates. Distilled from a project-specific `CLAUDE.md`. | Rename to `CLAUDE.md` in your project root, fill in the **PROJECT BRIEF** placeholders (§0), prune what doesn't apply. |
| `JAHIN_WRITING_BIBLE.md` | Abrar Jahin's publication system, distilled and generalized — sentence rules, paragraph moves, structural defaults, phrases-to-avoid, and the "know when to stop" meta-skill. | Read before drafting. Apply at **80–85%**, not 100% (see the calibration note at the top). |

## Suggested workflow for a new project
1. Copy `RESEARCH_OPERATING_MANUAL.md` → `CLAUDE.md`, fill in §0.
2. Point your AI collaborator at it: *"Read CLAUDE.md in full, inspect the directory,
   tell me which phase we're in and the next action, then wait."*
3. Keep `JAHIN_WRITING_BIBLE.md` open during Phase 4 (drafting).

## Provenance
Generalized from the `bci-review` project operating manual (`CLAUDE.md`) and the
`CLAUDE_NOTES.md` "Jahin publication system" notes. Both documents here are
field-independent distillations.

The original raw artifact this was distilled from — Abrar Jahin's paper-structuring
notes for a specific unpublished physics/GNN paper — is **deliberately not included**.
It is project-specific rather than general, and it describes work that has not been
published.
